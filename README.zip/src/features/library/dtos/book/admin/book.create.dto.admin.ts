export class BookCreateDtoAdmin{

}
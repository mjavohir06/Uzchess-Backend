import { ApiProperty } from '@nestjs/swagger';
import { Expose } from 'class-transformer';

export class NewsListDtoPublic {
  @ApiProperty()
  @Expose()
  id!: number;

  @ApiProperty()
  @Expose()
  title!: string;

  @ApiProperty()
  @Expose()
  image!: string;

  @ApiProperty()
  @Expose()
  content!: string;

  @ApiProperty()
  @Expose()
  date!: string;
}
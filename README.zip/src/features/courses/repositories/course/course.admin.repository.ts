import { Injectable } from "@nestjs/common";
import { ConfigService } from "@nestjs/config";
import { ObjectLiteral, Repository } from "typeorm";
import { BaseRepository } from "@/core/repository/BaseRepository";
import { InjectRepository } from "@nestjs/typeorm";
import { Course } from "../../entities/course.entity";
import { Author } from "@/features/common/entities/author.entity";
import { CourseCategory } from "../../entities/course-category.entity";
import { Language } from "@/features/common/entities/language.entity";
import { Difficulty } from "@/features/common/entities/difficulty.entity";



@Injectable()
export class CourseAdminRepository extends BaseRepository<Course> {
    constructor(
        protected readonly config: ConfigService,
        @InjectRepository(Course)
        protected readonly repo:Repository<Course>,
        @InjectRepository(Author)
        protected readonly author:Repository<Author>,
        @InjectRepository(CourseCategory)
        protected readonly catagory:Repository<CourseCategory>,
        @InjectRepository(Language)
        protected readonly language:Repository<Language>,
        @InjectRepository(Difficulty)
        protected readonly difficulty:Repository<Difficulty>,
    ){
        super()
    }

    async courseCountBy(where:Record<string,any>){
        return await this.repo.countBy(where)
    }

    async authorCountBy(where:Record<string,any>){
        return await this.author.countBy(where)
    }

    async languageCountBy(where:Record<string,any>){
        return await this.language.countBy(where)
    }

    async categoryCountBy(where:Record<string,any>){
        return await this.catagory.countBy(where)
    }

    async difficultyCountBy(where:Record<string,any>){
        return await this.difficulty.countBy(where)
    }

    async getAllCourse(userId?:number){
        return await Course.createQueryBuilder('courses')
      .leftJoinAndSelect('courses.likes', 'likes', 'likes.userId = :userId', { userId: userId })
      .leftJoinAndSelect('courses.author', 'author')
      .leftJoinAndSelect('courses.category', 'category')
      .leftJoinAndSelect('courses.difficulty', 'difficulty')
      .leftJoinAndSelect('courses.language', 'language')
      .getMany();
    }
    
}